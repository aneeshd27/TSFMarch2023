# TSF-Internship-Task
This is one of the tasks given to us in the internship we are doing with The Sparks Foundation i.e GRIP(Graduate Rotational Internship Program ) 


Task 1 - To Explore Supervised Machine Learning In this regression task, we will predict the percentage of marks that a student is expected to score based upon the number of hours they studied. This is a simple linear regression task as it involves just two variables. What will be predicted score if a student study for 9.25 hrs in a day?

Task 1 dataset- http://bit.ly/w-data

Task 2 - To Explore Unsupervised Machine Learning From the given ‘Iris’ dataset,we will predict the optimum number of clusters and represent it visually.

Task 2 dataset- https://drive.google.com/file/d/11Iq7YvbWZbt8VXjfm06brx66b10YiwK-/view?usp=sharing

Taak 3 - To Explore Decision Tree Algorithm.For the given ‘Iris’ dataset, create the Decision Tree classifier and 

visualize it graphically. The purpose is if we feed any new data to this 

classifier, it would be able to predict the right class accordingly.

Task 3 dataset- https://drive.google.com/file/d/11Iq7YvbWZbt8VXjfm06brx66b10YiwK-/view?usp=sharing

Task 4 - To explore Business Analytics.Perform ‘Exploratory Data Analysis’ on the provided dataset 

‘SampleSuperstore’

You are the business owner of the retail firm and want to see 

how your company is performing. You are interested in finding 

out the weak areas where you can work to make more profit. 

What all business problems you can derive by looking into the 

data? You can choose any of the tool of your choice 

(Python/R/Tableau/PowerBI/Excel).

Task 4 dataset-https://drive.google.com/file/d/1lV7is1B566UQPYzzY8R2ZmOritTW299S/view


