




Task 2 - To Explore Unsupervised Machine Learning From the given ‘Iris’ dataset,we will predict the optimum number of clusters and represent it visually.

Task 2 dataset- https://drive.google.com/file/d/11Iq7YvbWZbt8VXjfm06brx66b10YiwK-/view?usp=sharing
