
Taak 3 - To Explore Decision Tree Algorithm.For the given ‘Iris’ dataset, create the Decision Tree classifier and

visualize it graphically. The purpose is if we feed any new data to this

classifier, it would be able to predict the right class accordingly.

Task 3 dataset- https://drive.google.com/file/d/11Iq7YvbWZbt8VXjfm06brx66b10YiwK-/view?usp=sharing
